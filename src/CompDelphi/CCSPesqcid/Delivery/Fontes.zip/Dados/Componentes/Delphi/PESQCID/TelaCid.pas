unit TelaCid;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs;

type
  TFTelaCid = class(TForm)
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
   {FTelaCid: TFTelaCid;}

implementation

{$R *.DFM}

end.
