{ Turbo Pascal Unit:  pesqcid.pas                  }
{                                                 }
{ This is an interface unit containing integer    }
{ mappings of Topic IDs (names of Help            }
{ Topics) which are located in pesqcid.RTF     }
{                                                 }
{ This file is re-written by RoboHELP           }
{ whenever pesqcid.RTF is saved.   	          }
{                                                 }
{ However, the numeric values stored in           }
{ pesqcid.hh are the 'master values' and if you    }
{ modify the value in pesqcid.hh and then          }
{ save the pesqcid.RTF again, this file will   }
{ reflect the changed values.                     }
{                                                 }


Unit pesqcid;
   Interface
   Const

   ArquivosCID = 6;
   BotaoAjuda = 39;
   BotaoCopiar = 38;
   BotaoSair = 30;
   CampoDetalhe = 32;
   CCSSIS = 1;
   CodEscolhido = 29;
   CodigoCID = 8;
   Creditos = 2;
   DescricaoCID = 9;
   DetalheCID = 10;
   DiretorioCID = 7;
   Eventos = 28;
   Execute = 19;
   Exemplo = 23;
   FormHeight = 16;
   FormLeft = 14;
   FormPosition = 12;
   FormTop = 13;
   FormWidth = 15;
   FormWindowState = 11;
   Hierarquia = 25;
   Instala��o = 4;
   InstalacaoDelphi = 36;
   InstalacaoVB = 37;
   Introdu��o = 3;
   ListaDiagnosticos = 33;
   MensagensErro = 5;
   M�todos = 27;
   OnCanClose = 20;
   OnClose = 21;
   OnShow = 22;
   PalavraPesquisada = 35;
   PesquisaAutomatica = 18;
   PesquisaInicial = 17;
   Propriedades = 26;
   QtdDiag = 34;
   TelaPesquisa = 24;
   TipoPesquisa = 31;
	
   Implementation
   end.

