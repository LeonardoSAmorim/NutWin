Attribute VB_Name = "MacroPesqCid"

Sub PesqCID()
'
' PesqCID Macro
' Macro created 10/27/96 by Pablo
'
fPesqCID.Show
If fPesqCID.Psq1.CodigoCID <> "" Then
    Selection.InsertBefore Text:=fPesqCID.Psq1.CodigoCID + " " + fPesqCID.Psq1.DescricaoCID
    Selection.Collapse Direction:=wdCollapseEnd
    End If
End Sub

