library PesqCidXCntrl;

uses
  ComServ,
  PesqCidXCntrl_TLB in 'PesqCidXCntrl_TLB.pas',
  PesqCidImp in 'PesqCidImp.pas' {PesqCidX: CoClass},
  AboutPesqCid in 'AboutPesqCid.pas' {PesqCidXAbout};

{$E ocx}

exports
  DllGetClassObject,
  DllCanUnloadNow,
  DllRegisterServer,
  DllUnregisterServer;

{$R *.TLB}

{$R *.RES}

begin
end.
