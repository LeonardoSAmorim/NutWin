unit ExPesqCID;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  OleCtrls, PesqCidXCntrl_TLB, StdCtrls;

type
  TForm1 = class(TForm)
    Edit2: TEdit;
    Edit3: TEdit;
    Button1: TButton;
    PesqCidX1: TPesqCidX;
    Edit1: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure PesqCidX1CanClose(Sender: TObject; const NewCID: WideString;
      var CanClose: WordBool);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.DFM}

procedure TForm1.FormCreate(Sender: TObject);
begin
//Inicializa para pesquisar por indu��o de parto
Edit1.Text:='indu��o';
end;

procedure TForm1.Button1Click(Sender: TObject);
begin

//Inicializa a pesquisa
PesqCidX1.PesquisaInicial :=Edit1.text;

//Abre a tela de pesquisa para que o usuario escolha
//um diagnostico
if PesqCidX1.Execute then
   begin

   //Apresenta o codigo e a descricao do diagnostico escolhido
   Edit2.Text:=PesqCidX1.CodigoCID + '-'+PesqCidX1.DescricaoCID ;

   //Apresenta a ultima palavra pesquisada
   Edit3.Text:=PesqCidX1.PesquisaInicial;

   end;
end;

procedure TForm1.PesqCidX1CanClose(Sender: TObject;
  const NewCID: WideString; var CanClose: WordBool);
begin
if (Pos ('O6',NewCID) <> 0) then
   begin
   ShowMessage('Estes diagn�sticos s� podem ser usados em mulheres');
   CanClose:=False;
   end
else
    CanClose:=True;
end;

end.
