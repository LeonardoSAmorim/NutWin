VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} fPesqCID 
   Caption         =   "Pesquisa de CID-10"
   ClientHeight    =   900
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   2100
   OleObjectBlob   =   "fPesqCID.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "fPesqCID"
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub UserForm_Activate()
Psq1.Execute
fPesqCID.Hide
End Sub

