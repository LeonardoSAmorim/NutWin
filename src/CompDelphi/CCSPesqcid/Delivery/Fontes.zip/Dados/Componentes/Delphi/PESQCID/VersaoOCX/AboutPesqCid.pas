unit AboutPesqCid;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls, Buttons;

type
  TPesqCidXAbout = class(TForm)
    CtlImage: TSpeedButton;
    NameLbl: TLabel;
    OkBtn: TButton;
    CopyrightLbl: TLabel;
    DescLbl: TLabel;
  end;

procedure ShowPesqCidXAbout;

implementation

{$R *.DFM}

procedure ShowPesqCidXAbout;
begin
  with TPesqCidXAbout.Create(nil) do
    try
      ShowModal;
    finally
      Free;
    end;
end;

end.
