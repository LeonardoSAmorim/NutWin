unit FFnpNumericEdit;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, FnpNumericEdit, ExtCtrls;

type
  TForm1 = class(TForm)
    RadioGroup1: TRadioGroup;
    GroupBox1: TGroupBox;
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    GroupBox2: TGroupBox;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Button7: TButton;
    FnpNumericEdit1: TFnpNumericEdit;
    Label1: TLabel;
    procedure RadioGroup1Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure FnpNumericEdit1InvalidEntry(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.DFM}

procedure TForm1.RadioGroup1Click(Sender: TObject);
begin
  FnpNumericEdit1.Decimals := RadioGroup1.ItemIndex;
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  FnpNumericEdit1.AsInteger := 200;
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  FnpNumericEdit1.AsCurrency := 49.5762;
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
  FnpNumericEdit1.AsFloat := 3463.78345;
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
  Application.MessageBox(PChar(IntToStr(FnpNumericEdit1.AsInteger)), PChar('TFnpNumericEdit DEMO'), mb_OK);
end;

procedure TForm1.Button5Click(Sender: TObject);
begin
  Application.MessageBox(PChar(CurrToStr(FnpNumericEdit1.AsCurrency)), PChar('TFnpNumericEdit DEMO'), mb_OK);
end;

procedure TForm1.Button7Click(Sender: TObject);
begin
  Close;
end;

procedure TForm1.Button6Click(Sender: TObject);
begin
  Application.MessageBox(PChar(FloatToStr(FnpNumericEdit1.AsFloat)), PChar('TFnpNumericEdit DEMO'), mb_OK);
end;

procedure TForm1.FnpNumericEdit1InvalidEntry(Sender: TObject);
begin
  MessageBeep(0);
  Application.MessageBox(PChar('Invalid entry!'), PChar('TFnpNumericEdit DEMO'), mb_OK);
  FnpNumericEdit1.SetFocus;
end;

end.
