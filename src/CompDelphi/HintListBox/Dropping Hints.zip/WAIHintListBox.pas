unit WAIHintListBox;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls;

type
  TWAIHintListBox = class(TListBox)
  private
    FHintText: Boolean;
    FOnMouseExit: TNotifyEvent;
    FOnMouseEnter: TNotifyEvent;
    procedure SetHintText(const Value: Boolean);
    procedure SetOnMouseEnter(const Value: TNotifyEvent);
    procedure SetOnMouseExit(const Value: TNotifyEvent);
  protected
    { Private declarations }
  procedure CMMouseEnter(var Message: TMessage); message CM_MOUSEENTER;
  procedure CMMouseLeave(var Message: TMessage); message CM_MOUSELEAVE;

  public
      HintWin:THintWindow;

      constructor Create(AOwner: TComponent); override;
      destructor  Destroy; override;
      procedure DefaultHandler(var Message); Override;
  published

   Property OnMouseEnter:TNotifyEvent read FOnMouseEnter write SetOnMouseEnter;
   Property OnMouseExit:TNotifyEvent read FOnMouseExit write SetOnMouseExit;
   Property HintText:Boolean read FHintText write SetHintText;
   Procedure MouseMove(Shift: TShiftState; X, Y: Integer);override;
    { Published declarations }
  end;

procedure Register;

implementation

procedure Register;
begin
  RegisterComponents('WAISS', [TWAIHintListBox]);
end;

{ TWAIHintListBox }
{-----------------------------------------------------------------------------}
procedure TWAIHintListBox.CMMouseEnter(var Message: TMessage);
begin
  inherited;

  If assigned(FOnMouseEnter) then fonmouseenter(self);
end;
{-----------------------------------------------------------------------------}
procedure TWAIHintListBox.CMMouseLeave(var Message: TMessage);
begin
  inherited;
  HintWin.ReleaseHandle;
  If assigned(FOnMouseExit) then fonmouseexit(self);
end;
{-----------------------------------------------------------------------------}
constructor TWAIHintListBox.Create(AOwner: TComponent);
begin
  Inherited Create(AOwner);
  HintWin := THintWindow.Create(self);
  Hintwin.Color := clInfoBk;
  hintwin.Canvas.Font.Color := clInfoText;
end;
{-----------------------------------------------------------------------------}
procedure TWAIHintListBox.DefaultHandler(var Message);
var
   msgT:TMsg;
begin
  // convert message to TMsg
  MsgT.message := TMessage(Message).Msg;
  Inherited;
    if hintwin = nil then Exit;
    if (TMessage(Message).Msg = WM_VScroll) or
      (HintWin.IsHintMsg(MsgT) and
       //if it's WM_Mousemove then we don't want to hide the hint window
      (MsgT.message <> WM_MouseMove))
      then HintWin.ReleaseHandle
end;
{-----------------------------------------------------------------------------}
destructor TWAIHintListBox.Destroy;
begin
  Inherited;
end;
{-----------------------------------------------------------------------------}
procedure TWAIHintListBox.MouseMove(Shift: TShiftState; X, Y: Integer);
Var Ind:integer;
rct:TRect;
begin
if Not(HintText) then
begin  //Item hinting is off
  HintWin.ReleaseHandle;
  inherited;
  exit;
end;
  // Get the index of the item under the mouse pointer
 Ind := ItemAtPos(Point(x,y),true);
 // Check if it is a legal item
 If ind = -1 then exit;
 // Check if the Item Text is wider then the cliprectangle
 if Canvas.textWidth(Items[ind]) >
   ((Canvas.ClipRect.Right - Canvas.ClipRect.Left) -3) then
 Begin
   // Get the default item coordinates
   rct := ItemRect(ind);
   // Stretch it to fit the whole item text
   Rct.Right := Rct.Left + Canvas.textWidth(Items[ind])+9;
   // Fine tune theses values for apperance
   Rct.Top := Rct.Top -3;
   Rct.Bottom := rct.Bottom -1;
   rct.Left := rct.left -1;
   // now convert to screen coordinates so that THintWindow can use them
   rct.TopLeft := ClientToScreen(rct.TopLeft);
   rct.BottomRight := ClientToScreen(rct.BottomRight);
   // And show
   HintWin.ActivateHint(rct,items[ind]);
 end
 else
 HintWin.ReleaseHandle;
Inherited;

end;
{-----------------------------------------------------------------------------}
procedure TWAIHintListBox.SetHintText(const Value: Boolean);
begin
  FHintText := Value;
end;
{-----------------------------------------------------------------------------}
procedure TWAIHintListBox.SetOnMouseEnter(const Value: TNotifyEvent);
begin
  FOnMouseEnter := Value;
end;
{-----------------------------------------------------------------------------}
procedure TWAIHintListBox.SetOnMouseExit(const Value: TNotifyEvent);
begin
  FOnMouseExit := Value;
end;

end.
