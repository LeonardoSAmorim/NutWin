program hintp;

uses
  Forms,
  Hints in 'Hints.pas' {Form1},
  SubHints in 'SubHints.pas',
  AppProps in 'AppProps.pas' {Form2},
  AdataImg in 'AdataImg.pas' {Form3};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TForm2, Form2);
  Application.CreateForm(TForm3, Form3);
  Application.Run;
end.
