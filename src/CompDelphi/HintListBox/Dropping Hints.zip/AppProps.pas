unit AppProps;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ComCtrls, ExtCtrls;

type
  TForm2 = class(TForm)
    UpDown1: TUpDown;
    Edit1: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Edit2: TEdit;
    UpDown2: TUpDown;
    Label3: TLabel;
    Edit4: TEdit;
    UpDown3: TUpDown;
    Label4: TLabel;
    Shape1: TShape;
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    ColorDialog1: TColorDialog;
    procedure FormCreate(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form2: TForm2;

implementation

uses Hints;

{$R *.DFM}

procedure TForm2.FormCreate(Sender: TObject);
var str:string;

begin
  Str := 'Hint Playground'+#13+
       'This is the TApplication properties form'+#13+
       'On this form you can set many of the '+#13+
       'TApplications properties that control hints'

       +#13+#13+
       'To close this hint - click on the x at the top';


   form1.Clickhnt.ActivateatTopLeft(str,nil);
end;
{-----------------------------------------------------------------------------}
procedure TForm2.FormActivate(Sender: TObject);
var str:string;
rct:TRect;
begin
  Str := 'Hint Playground'+#13+
       'This is the TApplication properties form'+#13+
       'On this form you can set many of the '+#13+
       'TApplications properties that control hints'

       +#13+#13+
       'To close this hint - click on the x at the top';
rct := form1.Clickhnt.CalcHintRect(800,str,nil);
   Edit1.Text := IntToStr(Application.HinthidePause);
   Edit2.Text := IntToStr(Application.HintPause);
   Edit4.Text := IntToStr(Application.HintShortPause);
   Shape1.Brush.Color := Application.HintColor;
   form1.Clickhnt.ActivateHint(rct,str);
end;

procedure TForm2.Button1Click(Sender: TObject);
begin
ColorDialog1.Color := Shape1.Brush.Color;
if ColorDialog1.execute then
  Shape1.Brush.Color := ColorDialog1.Color;
end;
{-----------------------------------------------------------------------------}
procedure TForm2.Button2Click(Sender: TObject);
begin
  Application.HintHidePause := StrToInt(Edit1.Text);
  Application.HintPause := StrToInt(Edit2.Text);
  Application.HintShortPause := StrToInt(Edit4.Text);
  Application.HintColor := Shape1.Brush.Color;

end;

end.
