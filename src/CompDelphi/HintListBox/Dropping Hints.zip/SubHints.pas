unit SubHints;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Buttons,extctrls;

Type
TPaintLineHintWindow = class(THintWindow)
  public
  Procedure Paint;Override;
 end;
//----------------------------------
TQuestHintWindow = class(THintWindow)
public
  Procedure Paint;override;
  function CalcHintRect(MaxWidth: Integer; const AHint: string;
      AData: Pointer): TRect; override;
end;
//--------------------------------------------
TArtHintWindow = class(THintWindow)
private
  Rgn:HRGN;
  fTimer:TTimer;
  CircColor:TColor;
  ColDir:Boolean;
protected
  TextRect:TRect;
  Procedure FireTimer(Sender:TObject);
public
  procedure ActivateHint(Rect: TRect; const AHint: string);override;

  function CalcHintRect(MaxWidth: Integer;
    const AHint: string; AData: Pointer): TRect;override;
  Procedure Paint;override;
  Procedure ReleaseHandle;
  Constructor Create(AOwner:TComponent);Override;
end;
//------------------------
TClickHintWindow = class(THintWindow)
private
  ButtonRect:TRect;
protected
  GraphOb:TGraphic;
  procedure WMNCHitTest(var Message:TMessage);Message WM_NCHitTest;
public
   procedure ActivateHint(Rect: TRect; const AHint: string);override;
   procedure Paint;override;
   function CalcHintRect(MaxWidth: Integer;
    const AHint: string; AData: Pointer): TRect;override;
   procedure ActivateAtTopLeft(AHint:string;AData: Pointer);dynamic;
   procedure ActivateAtPoint(AHint:string;AData:Pointer;X,Y:integer);dynamic;
   procedure ActivateHintData(Rect: TRect; const AHint: string; AData: Pointer);override;
   procedure MouseDownProc(Sender:TObject;Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
   procedure MouseUpProc(Sender:TObject;Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
   Constructor Create(AOwner:TComponent);Override;
   property OnMouseDown;
   property OnMouseUp;
end;



implementation

{ TQuestHintWindow }
{-----------------------------------------------------------------------------}
function TQuestHintWindow.CalcHintRect(MaxWidth: Integer;
  const AHint: string; AData: Pointer): TRect;


begin
   // Get the info from the parent class
   Result := Inherited CalcHintRect(Maxwidth,Trim(AHint),AData);
   //Ensure that the height is at least 24 - so as to fit the question mark
   Result.Bottom := Result.Bottom + 3;
   If result.bottom < 20 then result.bottom := 20;
   // Widen it by 26 so as to fit the question mark
   Result.Right := Result.Right + 26;
   // Not Required - makes it look better

end;

{-----------------------------------------------------------------------------}
procedure TQuestHintWindow.Paint;
Var fnt:TFont;
rct:TRect;
begin
  With Canvas Do
  begin
    Fnt := Font;
    Font.Name := 'Arial'; //every body has it
    Font.Size := 12;
    Font.Style := [fsBold];
    Font.Color := clBlack;
    Pen.Width := 3;
    Pen.Color := clGray;
    Ellipse(2,2,20,20);
    Pen.Width := 1;
    Pen.Color := clSilver;
    Ellipse(2,2,20,20);
    TextOut(6,2,'?');
    Font := fnt;
    Font.Size := 8;// := fnt;
    Font.Style := [];
    Font.Color := clInfoText;
    Font.Name := 'MS Sans Serif';
    Rct := ClientRect;
    Rct.Left := 26;
    OffsetRect(Rct,0,4);
    DrawText(Handle,Pchar(Caption),Length(Caption),rct,DT_WORDBREAK	);
    //TextOut(26,5,Caption);
  end;

end;
{-----------------------------------------------------------------------------}
{ TPaintLineHintWindow }
{-----------------------------------------------------------------------------}
procedure TPaintLineHintWindow.Paint;
begin
  inherited; // draw the original text
  With canvas do
  begin
    Pen.Width := 2;
    Pen.Color := clBlue;
    PenPos := Point(0,0);
    LineTo(ClipRect.Right,0);
  end;
end;
{-----------------------------------------------------------------------------}
{ TArtHintWindow }
{-----------------------------------------------------------------------------}
procedure TArtHintWindow.ActivateHint(Rect: TRect; const AHint: string);
begin
  Inherited;
  // ccreate the region based on the window size
  rgn := CreateEllipticRgnIndirect(ClientRect);

  SetWindowRgn(Handle,rgn,true);
  // create the timer
  if fTimer = nil then
  Begin
    fTimer := TTimer.Create(self);
    FTimer.OnTimer := FireTimer;
    FTimer.Interval := 1;
  end;
end;
{-----------------------------------------------------------------------------}


function TArtHintWindow.CalcHintRect(MaxWidth: Integer;
  const AHint: string; AData: Pointer): TRect;
var yOff,xOff:integer;
begin
   Result := Inherited CalcHintRect(Maxwidth,Trim(AHint),AData);

   //Save This for the paint method
   TextRect := Result;
   //enlarge the rectangle so that we have place for the curves
   Result.right := Result.right + Result.right div 2 ;
   Result.bottom := Result.Bottom + Result.Bottom div 2 ;
   // figure out the middle where to put the text
   Xoff := (Result.right div 2) - (TextRect.Right div 2);
   Yoff := Result.bottom div 2 - TextRect.Bottom div 2;
   OffsetRect(TextRect,Xoff,yOff);
end;
{-----------------------------------------------------------------------------}
Constructor TArtHintWindow.Create(AOwner: TComponent);
begin
  Inherited;
  fTimer := nil;
end;
{-----------------------------------------------------------------------------}
procedure TArtHintWindow.FireTimer(Sender:TObject );
begin
  if colDir = false then
     inc(circcolor,20)
  else
     Dec(circcolor,20);

  If circcolor > 230 then
     ColDir := True;
  If circcolor < 10 then
     ColDir := False;
  Canvas.Pen.Color := RGb(Circcolor,circcolor,circcolor);
  Canvas.ellipse(0,0,Width-5,Height-5);

end;
{-----------------------------------------------------------------------------}
procedure TArtHintWindow.Paint;
begin
 // draw the text in middle of the hint window
 DrawText(Canvas.Handle,Pchar(Caption),Length(Caption),TextRect,DT_WORDBREAK or DT_Center	);
end;
{-----------------------------------------------------------------------------}
procedure TArtHintWindow.ReleaseHandle;
begin
// destroy the  timer so that no unnessecary
// drawing takes place
  FTimer.Free;
  Ftimer := nil;
  DestroyHandle;
end;
{-----------------------------------------------------------------------------}
{ TClickHintWindow }
{-----------------------------------------------------------------------------}
procedure TClickHintWindow.ActivateAtPoint(AHint: string; AData: Pointer;
  X,Y:integer);
var rct:TRect;
begin

  Rct := CalcHintRect(Screen.Width,ahint,AData);

  OffsetRect(rct,x,y);

  ActivateHintData(rct,ahint,Adata);
end;
{-----------------------------------------------------------------------------}
procedure TClickHintWindow.ActivateAtTopLeft(AHint: string;AData: Pointer);
var rct:TRect;
begin
  Rct := CalcHintRect(Screen.Width,ahint,AData);
  // we don't have to do any thing becaue CalcHintrect returns at 0,0
  ActivateHintData(rct,ahint,Adata);
end;
{-----------------------------------------------------------------------------}
procedure TClickHintWindow.ActivateHint(Rect: TRect; const AHint: string);
begin
  GraphOb := nil;
  inherited;
end;
{-----------------------------------------------------------------------------}
procedure TClickHintWindow.ActivateHintData(Rect: TRect;
  const AHint: string; AData: Pointer);
begin
  ActivateHint(Rect,AHint);
  // ActivateHint automaticlly assigns nil to graphob so
  // if a pointer was passed we assign it here
  if TObject(Adata) is TGraphic then
  Begin
    GraphOb := TGraphic(AData);
    Invalidate;
  end;
end;
{-----------------------------------------------------------------------------}
function TClickHintWindow.CalcHintRect(MaxWidth: Integer;
  const AHint: string; AData: Pointer): TRect;
var  graph:TGraphic;
begin
  Result := Inherited CalcHintRect(Maxwidth,Trim(AHint),AData);
  //add space for the close button
  Result.Right := Result.Right + 20;
  if TObject(aData) is TGraphic then
  begin

    graph := TGraphic(aData);
    // add space for the image
    Result.Right := Result.Right + Graph.Width+5;
    // make sure that the image fits into the hint window
    if Result.Bottom < graph.Height +4 then
       Result.Bottom := Graph.Height +4;
  end;
end;
{-----------------------------------------------------------------------------}
constructor TClickHintWindow.Create(AOwner: TComponent);
begin
  inherited;
  //assign procedures
  OnMouseDown := MouseDownProc;
  OnMouseUp := MouseUpProc;
  Color := clInfoBk;
end;
{-----------------------------------------------------------------------------}
procedure TClickHintWindow.MouseDownProc(Sender:TObject;Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  // draw down button
  DrawFrameControl(Canvas.Handle,buttonrect,DFC_CAPTION,DFCS_CAPTIONCLOSE	+ DFCS_PUSHED	);
end;
//---------------------------------------------------
procedure TClickHintWindow.MouseUpProc(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  // draw upbutton and hide window
  DrawFrameControl(Canvas.Handle,buttonrect,DFC_CAPTION,DFCS_CAPTIONCLOSE	);
  ReleaseHandle;
end;
{-----------------------------------------------------------------------------}
procedure TClickHintWindow.Paint;
var txtrct,rct:TRect;
begin
  rct := ClientRect;
  // add space for button
  rct.Right := rct.Right - 15;
  OffsetRect(rct,2,2);
  if GraphOb <> nil then
  Begin
  // save text rectangle position
    txtrct := CalcHintRect(Screen.Width,Caption,nil);
    // make space for graphic
    OffsetRect(txtrct,GraphOb.Width+5,0);
    Canvas.Draw(2,2,GraphOb);
  end
  else
    TxtRct := Rct;
  // calc button rectangle
  ButtonRect.Top := 2;
  ButtonRect.Left := width - 18;
  ButtonRect.Bottom := 16;
  ButtonRect.Right := Width -4;
  // draw text and button
  DrawText(Canvas.Handle,Pchar(Caption),Length(Caption),txtrct,DT_WORDBREAK	);
  DrawFrameControl(Canvas.Handle,buttonrect,DFC_CAPTION,DFCS_CAPTIONCLOSE	);
end;
{-----------------------------------------------------------------------------}
procedure TClickHintWindow.WMNCHitTest(var Message: TMessage);
var pnt:TPoint;
begin
    // get coordinates from the message
    pnt := Point(Message.LParamLo,Message.LParamHi);
    if PtInRect(ButtonRect,pnt) then
      // it is part of the button
      Message.Result := HTClient
    else
      // it is elsewhere
      Message.Result := HTTRansparent;
end;
{-----------------------------------------------------------------------------}
end.
