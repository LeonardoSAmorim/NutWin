unit Hints;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Buttons,  ExtCtrls, ComCtrls, WAIHintListBox ,{This is our hint window
  subclass file --> }subhints ,typinfo;

type
  TForm1 = class(TForm)
    Label1: TLabel;
    Label6: TLabel;
    StatusBar1: TStatusBar;
    Panel1: TPanel;
    Panel2: TPanel;
    Splitter1: TSplitter;
    WAIHintListBox1: TWAIHintListBox;
    Bevel1: TBevel;
    Label7: TLabel;
    Panel3: TPanel;
    SpeedButton1: TSpeedButton;
    SpeedButton2: TSpeedButton;
    SpeedButton3: TSpeedButton;
    SpeedButton4: TSpeedButton;
    SpeedButton5: TSpeedButton;
    Label9: TLabel;
    Bevel2: TBevel;
    Label10: TLabel;
    Button3: TButton;
    Panel4: TPanel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Label8: TLabel;
    Bevel3: TBevel;
    Label11: TLabel;
    SpeedButton6: TSpeedButton;
    Button1: TButton;
    Bevel4: TBevel;
    Bevel5: TBevel;
    Button2: TButton;
    Button4: TButton;
    Image1: TImage;
    Label12: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure FormMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure FormMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormMouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure SpeedButton1Click(Sender: TObject);
    procedure SpeedButton2Click(Sender: TObject);
    procedure SpeedButton3Click(Sender: TObject);
    procedure SpeedButton4Click(Sender: TObject);

    procedure Button3Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure SpeedButton5Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);

  
  private
    { Private declarations }

    Procedure CMMouseLeave(Var Message:TMessage);Message CM_MouseLeave;
    procedure OnHintProc(Sender:TObject);
   
  public
    { Public declarations }
    HintWin:ThintWindow;
    mX,mY,fX,fY :integer;
    ClickHnt:TClickHintWindow;
    mDown:Boolean;
    Procedure ShowHintProc(var HintStr: string; var CanShow: Boolean; var HintInfo: THintInfo);

  end;
  // This is a simple hint window that paints a blue
  // line on top of the hint window



var
  Form1: TForm1;

implementation

uses AppProps,  AdataImg;

//uses Unit2;



{$R *.DFM}
{-----------------------------------------------------------------------------}
procedure TForm1.FormCreate(Sender: TObject);
var I:integer;
PropInfo:PPropInfo;
propCapt:string;

begin
  HintWin := THintWindow.Create(self);
  HintWin.Color := clInfoBk;
  HintWin.Canvas.Font.Color := ClInfoText;
  Application.OnShowHint := ShowHintProc;
  Application.OnHint := OnHintProc;
  ClickHnt := TClickHintWindow.Create(Self);
  for i := 0 to ComponentCount-1  do
  begin

    PropInfo := GetPropInfo(Components[i].ClassInfo,'Caption');
    if (Propinfo = nil) or (PropInfo.PropType^.kind <> tklString) then continue;
    PropCapt := GetStrProp(Components[i],propinfo);
    if propCapt = '' then continue;
    WAIHintListBox1.Items.Add(propCapt);
  end;
  for i := 0 to 15 do
  begin
    Label12.Hint := Label12.Hint + WAIHintListBox1.Items[i] + #13 ;
    Label12.Hint := Label12.hint + WAIHintListBox1.Items[16]
  end;
  SpeedButton6.Caption := 'Click to give me '+#13+'Multi-line Hint';
end;
{-----------------------------------------------------------------------------}
procedure TForm1.FormMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
Var Rct:TRect; // see the August edition of Delphi Informant for a full
               // article on the TRect
s:String;
begin
  // Compose the Hint text

  S := ' x = ' + IntToStr(X) +
       ' , y = ' + IntToStr(Y);

  // If mouseDown then add the height and width
  If mDown then
  Begin
    S := ' Left = ' + IntToStr(X) +
       ' , Top = ' + IntToStr(Y);
    s := s + #13 +//add a new line charachter
       ' Width = ' + IntToStr(x-mX) +
       ' , Height = '+ IntToStr(y-mY);
    s := S + #13+ ' - See The Code in the OnMouseMove Event';
    // Now erase the previous FocusRect
    Canvas.DrawFocusRect(Rect(mX,mY,fX,fY));
    // and draw the new coordinates
    Canvas.DrawFocusRect(Rect(mX,mY,X,Y));
    // Save these for later
    fX := X;
    fY := Y;
  end
  else
    S := ' x = ' + IntToStr(X) +
       ' , y = ' + IntToStr(Y);

  // Get the string dimentions
  rct := HintWin.CalcHintRect(Screen.Width,S,nil);

  // Add the Hint offsets to the rectangle.
  // Note: This can be problematic since the x,y represent the cusors hotsopt
  // which isn't always the top left of the cursor. The Application cursor tests
  // for this and positions the window appropriatlly. However this is a very complex test
  // that cannot be implemented here. Instead we will risk it and position it at X  and
  // Y + 16
  OffsetRect(Rct,x,y + 20);
  Rct.Right := Rct.Right + 3;//explained in article text;

  // Convert to Client Cordinates
  Rct.TopLeft := ClientToScreen(Rct.TopLeft);
  Rct.BottomRight := ClientToScreen(Rct.BottomRight);

  HintWin.ActivateHint(Rct,s);
end;
{-----------------------------------------------------------------------------}
procedure TForm1.FormMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
MDown := true;
mX := x;
mY := y;
end;
{-----------------------------------------------------------------------------}
procedure TForm1.FormMouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  mDown := false;
  // erase the previous FocusRect
  Canvas.DrawFocusRect(Rect(mX,mY,fX,fY));
  fX := 0;
  fY := 0;
end;
{-----------------------------------------------------------------------------}
procedure TForm1.CMMouseLeave(var Message: TMessage);
begin
  HintWin.ReleaseHandle; // Hide the window
  MouseUp(mbRight,[],0,0);   // let mouse up take care of clean up
end;
{-----------------------------------------------------------------------------}
procedure TForm1.SpeedButton1Click(Sender: TObject);
begin
HintWindowClass := THintWindow;

end;
{-----------------------------------------------------------------------------}
procedure TForm1.SpeedButton2Click(Sender: TObject);
begin
  HintWindowClass := TPaintLineHintWindow;
end;
{-----------------------------------------------------------------------------}
procedure TForm1.SpeedButton3Click(Sender: TObject);
begin
  HintWindowClass := TQuestHintWindow;
end;
{-----------------------------------------------------------------------------}
procedure TForm1.SpeedButton4Click(Sender: TObject);
begin
  HintWindowClass := TArtHintWindow;
end;
{-----------------------------------------------------------------------------}

{-----------------------------------------------------------------------------}
procedure TForm1.Button3Click(Sender: TObject);
begin
Form2.Show;
end;
{-----------------------------------------------------------------------------}
procedure TForm1.ShowHintProc(var HintStr: string; var CanShow: Boolean;
  var HintInfo: THintInfo);

  Var
  TopRect,BottomRect:TRect;

begin
  With HintInfo do
  Begin
    // Split personality hit testing
    TopRect := Rect(0,0,HintControl.width,HintControl.Height div 2) ;
    BottomRect := Rect(0,HintControl.Height div 2,HintControl.width,HintControl.height);
    if hintControl = Panel1 then
      // Hit Testing for top part
      If PtInRect(TopRect,CursorPos) then
      Begin
        HintStr := 'Top Part' + #13 + '- See The code in the OnShowHint Event';
        CursorRect := topRect;
      end
      else            //its part of the bottom
      Begin
        HintStr := 'Bottom Part'+ #13 + '- See The code in the OnShowHint Event';
        CursorRect := BottomRect;
      end;
    HintData := Form3.Image1.Picture.Graphic;
    // Stuborn lables
    // Remeber the HintWindowClass here refers to the ThintInfo feild
    // not the golbal HintWindowClass
    if hintControl = Label2 then HintWindowClass := THintWindow;
    if hintControl = Label3 then HintWindowClass := TPaintLineHintWindow;
    if hintControl = Label4 then HintWindowClass := TQuestHintWindow;
    if hintControl = Label5 then HintWindowClass := TArtHintWindow;
    if hintControl = Label8 then HintWindowClass := TClickHintWindow;
    // this is the very stuborn image control in the corner
    if hintcontrol = image1 then
    begin
      hintwindowclass := TClickHintWindow;
      HintData := Image1.Picture.graphic;
    end;
   
end;

end;
{-----------------------------------------------------------------------------}
procedure TForm1.Button2Click(Sender: TObject);
begin
  SpeedButton6.Caption := 'I have a multi - Line hint';
  // By adding Linefeeds to a hint string we can force a new line
  SpeedButton6.Hint := 'A hint can have more then one line of text'+#13+
                  'By adding Linefeeds (#13) to a hint string we can force a new line'+#13+
                  'To see how this is done look at the Button2Click event handler';
end;
{-----------------------------------------------------------------------------}
procedure TForm1.OnHintProc(Sender: TObject);
begin
  //in delphi 4 we could just leave this up to the AutoHint property
   StatusBar1.SimpleText := GetLongHint(application.hint);
end;
{-----------------------------------------------------------------------------}
procedure TForm1.Button1Click(Sender: TObject);
begin
  Form3.Show;
end;
{-----------------------------------------------------------------------------}
procedure TForm1.FormActivate(Sender: TObject);
var str:string;

begin
Str := 'Welcome to Hint Playground'+#13+
       'This software is the sample source code'+#13+
       'for the Delphi Informant Article'+#13+#13+
       'This is the Main Form of the application.'+#13+
       'It demonstrates many of the concepts expained in'+#13+
       'the article'+#13+#13+
       'To close this hint - click on the x at the top';
   Clickhnt.ActivateAtTopLeft(str,icon);
  end;
{-----------------------------------------------------------------------------}
procedure TForm1.SpeedButton5Click(Sender: TObject);
begin
HintWindowClass := TClickHintWindow;
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
if button4.Caption = 'Set Form.Hint' then
begin
  Self.Hint := 'This is the forms hint';
  Button4.Caption := 'Unset Form.Hint';
end
else
begin
  Self.Hint := '';
  Button4.Caption := 'Set Form.Hint';
end;
end;



end.
