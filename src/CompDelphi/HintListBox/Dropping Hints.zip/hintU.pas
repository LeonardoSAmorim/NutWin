unit hintU;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, WTwkListBox;

type
  TForm1 = class(TForm)
    WTwkListBox1: TWTwkListBox;
    Button1: TButton;
    procedure FormCreate(Sender: TObject);
    procedure FormMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure FormMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormMouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
    Procedure CMMouseLeave(Var Message:TMessage);Message CM_MouseLeave;
   
  public
    { Public declarations }
    HintWin:ThintWindow;
    mX,mY,fX,fY :integer;

    mDown:Boolean;
     
  end;

var
  Form1: TForm1;

implementation

{$R *.DFM}
{-----------------------------------------------------------------------------}
procedure TForm1.FormCreate(Sender: TObject);
begin
  HintWin := THintWindow.Create(self);
  HintWin.Color := clInfoBk;
  HintWin.Canvas.Font.Color := ClInfoText;

end;
{-----------------------------------------------------------------------------}
procedure TForm1.FormMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
Var Rct:TRect; // see the August edition of Delphi Informant for a full
               // article on the TRect
s:String;
begin
  // Compose the Hint text

  S := ' x = ' + IntToStr(X) +
       ' , y = ' + IntToStr(Y);

  // If mouseDown then add the height and width
  If mDown then
  Begin
    S := ' Left = ' + IntToStr(X) +
       ' , Top = ' + IntToStr(Y);
    s := s + #13 +//add a new line charachter
       ' Width = ' + IntToStr(x-mX) +
       ' , Height = '+ IntToStr(y-mY);
    // Now erase the previous FocusRect
    Canvas.DrawFocusRect(Rect(mX,mY,fX,fY));
    // and draw the new coordinates
    Canvas.DrawFocusRect(Rect(mX,mY,X,Y));
    // Save these for later
    fX := X;
    fY := Y;
  end
  else
    S := ' x = ' + IntToStr(X) +
       ' , y = ' + IntToStr(Y);

  // Get the string dimentions
  rct := HintWin.CalcHintRect(Screen.Width,S,nil);

  // Add the Hint offsets to the rectangle.
  // Note: This can be problematic since the x,y represent the cusors hotsopt
  // which isn't always the top left of the cursor. The Application cursor tests
  // for this and positions the window appropriatlly. However this is a very complex test
  // that cannot be implemented here. Instead we will risk it and position it at X  and
  // Y + 16
  OffsetRect(Rct,x,y + 20);
  Rct.Right := Rct.Right + 3;//explained in article text;

  // Convert to Client Cordinates
  Rct.TopLeft := ClientToScreen(Rct.TopLeft);
  Rct.BottomRight := ClientToScreen(Rct.BottomRight);

  HintWin.ActivateHint(Rct,s);
end;
{-----------------------------------------------------------------------------}
procedure TForm1.FormMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
MDown := true;
mX := x;
mY := y;
end;
{-----------------------------------------------------------------------------}
procedure TForm1.FormMouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  mDown := false;
  // erase the previous FocusRect
  Canvas.DrawFocusRect(Rect(mX,mY,fX,fY));
  fX := 0;
  fY := 0;
end;

procedure TForm1.CMMouseLeave(var Message: TMessage);
begin
  HintWin.ReleaseHandle; // Hide the window
  MouseUp(mbRight,[],0,0);   // let mouse up take care of clean up
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
wtwklistbox1.items.add('dddddd');
wtwklistbox1.Width := wtwklistbox1.Width + 5;
end;

end.
