unit AdataImg;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtDlgs, ExtCtrls, StdCtrls;

type
  TForm3 = class(TForm)
    ScrollBox1: TScrollBox;
    Button1: TButton;
    Button2: TButton;
    Image1: TImage;
    OpenPictureDialog1: TOpenPictureDialog;
    procedure Button1Click(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure Button2Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form3: TForm3;

implementation

uses Hints;

{$R *.DFM}

procedure TForm3.Button1Click(Sender: TObject);
begin
if OpenPictureDialog1.Execute then
  image1.Picture.LoadFromFile(OpenPictureDialog1.FileName);
end;
{-----------------------------------------------------------------------------}
procedure TForm3.FormActivate(Sender: TObject);
var str:String;
begin
 Image1.Picture.Graphic := Form1.Icon;
  Str := 'Hint Playground'+#13+
       'You can specify a image for AData parameter'+#13+
       'on this form. The aData parameter is passed in'+#13+
       'the THintInfo record from the OnShowHint event.'+#13+
       'In this application the TClickHintWindow interprets'+#13+
       'it as a TGraphic ,all other THintWindow ignore it'

       +#13+#13+
       'To close this hint - click on the x at the top';


   form1.Clickhnt.ActivateatTopLeft(str,nil);
end;

procedure TForm3.Button2Click(Sender: TObject);
begin
  Hide;
end;

end.
